import awsLambdaFastify from "@fastify/aws-lambda";
import fastify from "fastify";
import fastifyCors from "@fastify/cors";
import dotenv from "dotenv";
import crypto from "crypto";
import cookie from "fastify-cookie";
import jwt from "jsonwebtoken";

dotenv.config();

const clientId = process.env.COGNITO_CLIENT_ID;
const clientSecret = process.env.COGNITO_CLIENT_SECRET;
const region = process.env.REGION;
const jwtSecret = process.env.JWT_SECRET;

const app = fastify({ logger: true });

app.register(fastifyCors, {
  origin: ["http://localhost:3000", process.env.FRONTEND_URL_VERCEL],
  credentials: true,
});

app.register(cookie);

app.addContentTypeParser(
  "application/json",
  { parseAs: "string" },
  (req, body, done) => {
    try {
      const json = JSON.parse(body);
      done(null, json);
    } catch (err) {
      done(err);
    }
  }
);

function calculateSecretHash(username, clientId, clientSecret) {
  return crypto
    .createHmac("sha256", clientSecret)
    .update(username + clientId)
    .digest("base64");
}

function verifyToken(token) {
  try {
    return jwt.verify(token, jwtSecret);
  } catch (err) {
    return null;
  }
}

// Registration route
app.post("/auth/register", async (req, reply) => {
  try {
    const { email, password, name, phone } = req.body;
    console.log("Register request body:", req.body);

    const secretHash = calculateSecretHash(email, clientId, clientSecret);

    const response = await fetch(
      `https://cognito-idp.${region}.amazonaws.com/`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/x-amz-json-1.1",
          "X-Amz-Target": "AWSCognitoIdentityProviderService.SignUp",
          "X-Amz-User-Agent": "aws-amplify/3.0",
        },
        body: JSON.stringify({
          ClientId: clientId,
          SecretHash: secretHash,
          Username: email,
          Password: password,
          UserAttributes: [
            { Name: "email", Value: email },
            { Name: "given_name", Value: name },
            { Name: "phone_number", Value: phone },
          ],
        }),
      }
    );

    const data = await response.json();

    if (!response.ok) {
      return reply
        .status(400)
        .send({ message: data.message || "Registration error" });
    }

    reply.status(201).send({ id: data.UserSub, email, name });
  } catch (error) {
    app.log.error("Registration failed:", error);
    reply.status(500).send({ message: "Internal Server Error" });
  }
});

// Login route
app.post("/auth/login", async (req, reply) => {
  const { email, token } = req.body;
  const payload = { email };
  const jwtToken = jwt.sign(payload, jwtSecret, { expiresIn: "1h" });

  reply
    .setCookie("token", jwtToken, {
      httpOnly: true,
      sameSite: "lax",
      secure: process.env.NODE_ENV === "production",
      path: "/",
      maxAge: 3600,
    })
    .send({ message: "Login successful" });
});

// Logout route
app.post("/auth/logout", async (req, reply) => {
  reply.clearCookie("token", { path: "/" }).send({ message: "Logged out" });
});

// Get user from JWT
app.get("/auth/me", async (req, reply) => {
  const token = req.cookies.token;
  const user = verifyToken(token);

  if (!user) return reply.status(401).send({ message: "Unauthorized" });
  reply.send({ user });
});

// Silent auth refresh (optional pattern)
app.post("/auth/refresh", async (req, reply) => {
  const token = req.cookies.token;
  const user = verifyToken(token);

  if (!user) return reply.status(401).send({ message: "Unauthorized" });

  const newToken = jwt.sign({ email: user.email }, jwtSecret, {
    expiresIn: "1h",
  });
  reply
    .setCookie("token", newToken, {
      httpOnly: true,
      sameSite: "lax",
      secure: process.env.NODE_ENV === "production",
      path: "/",
      maxAge: 3600,
    })
    .send({ message: "Token refreshed" });
});

export const handler = awsLambdaFastify(app);

if (process.env.NODE_ENV === "development") {
  app.listen({ port: 5000 }, (err) => {
    if (err) {
      console.error("Startup error:", err);
      process.exit(1);
    }
    console.log("Local API running at http://localhost:5000");
  });
}
